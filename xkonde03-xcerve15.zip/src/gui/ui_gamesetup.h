/********************************************************************************
** Form generated from reading UI file 'gamesetup.ui'
**
** Created by: Qt User Interface Compiler version 5.3.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GAMESETUP_H
#define UI_GAMESETUP_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GameSetup
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton;
    QWidget *widget;
    QGridLayout *gridLayout;
    QLabel *label;
    QSpinBox *spinBox;
    QLabel *label_2;
    QSpinBox *spinBox_2;
    QLabel *label_3;
    QSpinBox *spinBox_3;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *GameSetup)
    {
        if (GameSetup->objectName().isEmpty())
            GameSetup->setObjectName(QStringLiteral("GameSetup"));
        GameSetup->resize(400, 300);
        centralwidget = new QWidget(GameSetup);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(150, 180, 75, 23));
        widget = new QWidget(centralwidget);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(90, 80, 201, 74));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        spinBox = new QSpinBox(widget);
        spinBox->setObjectName(QStringLiteral("spinBox"));
        spinBox->setMinimum(5);
        spinBox->setMaximum(11);
        spinBox->setSingleStep(2);

        gridLayout->addWidget(spinBox, 0, 1, 1, 1);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        spinBox_2 = new QSpinBox(widget);
        spinBox_2->setObjectName(QStringLiteral("spinBox_2"));
        spinBox_2->setMinimum(2);
        spinBox_2->setMaximum(4);
        spinBox_2->setSingleStep(1);
        spinBox_2->setValue(2);

        gridLayout->addWidget(spinBox_2, 1, 1, 1, 1);

        label_3 = new QLabel(widget);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        spinBox_3 = new QSpinBox(widget);
        spinBox_3->setObjectName(QStringLiteral("spinBox_3"));
        spinBox_3->setMinimum(12);
        spinBox_3->setMaximum(24);
        spinBox_3->setSingleStep(12);
        spinBox_3->setValue(12);

        gridLayout->addWidget(spinBox_3, 2, 1, 1, 1);

        GameSetup->setCentralWidget(centralwidget);
        menubar = new QMenuBar(GameSetup);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 400, 21));
        GameSetup->setMenuBar(menubar);
        statusbar = new QStatusBar(GameSetup);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        GameSetup->setStatusBar(statusbar);

        retranslateUi(GameSetup);

        QMetaObject::connectSlotsByName(GameSetup);
    } // setupUi

    void retranslateUi(QMainWindow *GameSetup)
    {
        GameSetup->setWindowTitle(QApplication::translate("GameSetup", "MainWindow", 0));
        pushButton->setText(QApplication::translate("GameSetup", "Vytvorit", 0));
        label->setText(QApplication::translate("GameSetup", "Sirka a vyska: ", 0));
        label_2->setText(QApplication::translate("GameSetup", "Pocet hracu: ", 0));
        label_3->setText(QApplication::translate("GameSetup", "Pocet karet: ", 0));
    } // retranslateUi

};

namespace Ui {
    class GameSetup: public Ui_GameSetup {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GAMESETUP_H
