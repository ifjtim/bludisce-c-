/********************************************************************************
** Form generated from reading UI file 'labyrint.ui'
**
** Created by: Qt User Interface Compiler version 5.3.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LABYRINT_H
#define UI_LABYRINT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Labyrint
{
public:
    QWidget *centralwidget;
    QGraphicsView *graphicsView;

    void setupUi(QMainWindow *Labyrint)
    {
        if (Labyrint->objectName().isEmpty())
            Labyrint->setObjectName(QStringLiteral("Labyrint"));
        Labyrint->resize(800, 600);
        centralwidget = new QWidget(Labyrint);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        graphicsView = new QGraphicsView(centralwidget);
        graphicsView->setObjectName(QStringLiteral("graphicsView"));
        graphicsView->setGeometry(QRect(0, 0, 256, 192));
        Labyrint->setCentralWidget(centralwidget);

        retranslateUi(Labyrint);

        QMetaObject::connectSlotsByName(Labyrint);
    } // setupUi

    void retranslateUi(QMainWindow *Labyrint)
    {
        Labyrint->setWindowTitle(QApplication::translate("Labyrint", "MainWindow", 0));
    } // retranslateUi

};

namespace Ui {
    class Labyrint: public Ui_Labyrint {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LABYRINT_H
